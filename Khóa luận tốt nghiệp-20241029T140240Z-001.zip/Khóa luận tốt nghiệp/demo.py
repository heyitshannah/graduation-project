import pandas as pd
file_path = 'recipes_ingredients_processed.xlsx'
data = pd.read_excel(file_path, sheet_name='Sheet1')

# First, I will extract the ingredients from the dataset

ingredient_columns = [col for col in data.columns if 'Ingredient' in col]
ingredients = pd.concat([data[col] for col in ingredient_columns], axis=1)
ingredients.columns = ingredient_columns

# Next, I will preprocess the ingredients       

import re
from spacy.lang.en import English
nlp = English()

def clean_ingredient_text(text):
    if pd.isna(text):
        return text
    text = re.sub(r'��', '', text)
    text = re.sub(r'(\\d)([a-zA-Z])', r'\\1 \\2', text)
    doc = nlp(text)
    cleaned_text = ' '.join([token.text for token in doc if not token.is_stop and not token.is_punct])
    return cleaned_text

ingredients_cleaned = ingredients.applymap(clean_ingredient_text)

# Next, I will extract the quantities, units, and ingredients from the cleaned ingredients

import spacy
nlp = spacy.load('en_core_web_sm')

def extract_info_with_nlp(ingredient_text):
    doc = nlp(ingredient_text)
    quantities = []
    units = []
    ingredients = []
    elif token.dep_ == 'pobj':
    ingredients.append(token.text)
    ingredients.append(token.text)
    ingredients.append(token.text)
    ingredients.append(token.text)
    return quantities, units, ingredients

quantities = ingredients_cleaned.applymap(lambda x: extract_info_with_nlp(x)[0])

units = ingredients_cleaned.applymap(lambda x: extract_info_with_nlp(x)[1])

ingredients = ingredients_cleaned.applymap(lambda x: extract_info_with_nlp(x)[2])

# Finally, I will combine the cleaned ingredient data with the recipe names

cleaned_data = pd.concat([data['Recipe Name'], quantities, units, ingredients], axis=1)

# Save the cleaned data to a new Excel file

cleaned_data.to_excel('recipes_ingredients_cleaned.xlsx', index=False)

print('Cleaned data saved to recipes_ingredients_cleaned.xlsx')
